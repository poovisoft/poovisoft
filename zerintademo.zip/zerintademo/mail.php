<?php
if(isset($_POST['submit'])) {
    $type=$_POST['TYPE'];
    $drugLicense=$_POST['drugLicense'];
    $gstNo=$_POST['gstNo'];
    $FranchiseArea=$_POST['FranchiseArea'];
    $Name=$_POST['Name'];
    $EmailID= $_POST['EmailID'];
    $ContactNumber= $_POST['ContactNumber'];
    $Address = $_POST['Address'];
    //$ID =$_POST['ID'];
    /*$COMPCODE = $_POST['COMPCODE'];
    $reference = $_POST['reference'];
    $AD_CODE1 = $_POST['AD_CODE1'];
    $AD_CODE2 = $_POST['AD_CODE2'];
    $reference = $_POST['reference'];*/
    $to='meenatchipkr@gmail.com';
    $subject='Enquiry Form Submission';
    $message= "I am looking for ".$type."\n".
    "I have  ".$drugLicense."\n".
    "I have  ". $gstNo."\n". 
    "My Franchise Area for PCD will be  ".$FranchiseArea."\n". 
    "My details for Franchise"."\n".
    "Name : ". $Name."\n". "Email Address : ".$EmailID."\n". 
    "Mobile No : ". $ContactNumber."\n". 
    "Address : ".$Address."\n" ;
    $headers="From: ".$EmailID."";
    if(mail($to,$subject,$message,$headers)){
        alert ("Sent Successfully! Thank you ".$name." We will contact you shortly ");
}
else{
    alert( "Something went wrong!");
 }

    
}

    
   
             
            
    

   
    

?>