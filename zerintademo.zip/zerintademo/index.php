<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Zerinta</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- CSS -->
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
    <link rel="stylesheet" href="myProjects/webProject/icofont/css/icofont.min.css">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="css/swiper-bundle.min.css" />

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="myProjects/webProject/icofont/css/icofont.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0 px-4 px-lg-5">
        <a href="index.html" class="navbar-brand d-flex align-items-center">
            <h2 class="m-0 text-primary"><img class="img-fluid me-2" src="img/logo.png" alt="" style="max-width: 90px; height: auto;"></h2>
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-4 py-lg-0">
                <a href="#" class="nav-item nav-link active js-scroll-trigger">Home</a>
                <a href="#about" class="nav-item nav-link js-scroll-trigger">About</a>
                <a href="#pcdfranchise" class="nav-item nav-link js-scroll-trigger">pcd franchise</a>
                <a href="#products" class="nav-item nav-link js-scroll-trigger">products</a>
                <a href="#thirdparty" class="nav-item nav-link js-scroll-trigger">third party</a>
            </div>
            <div class="h-100 d-lg-inline-flex align-items-center d-none">
                <a href="#inquiry" style="padding: 10px 15px; background:#AC8D4D;border: 1px solid #F9E39A; border-radius:10px; box-shadow: 2px 2px 5px #F9E39A; color:#fff; ">FRANCHISE ENQUIRY</a>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

 <!--slider start-->
 <div class="slideshow-container">
 <div class="container-fluid hero-header bg-light py-5 mb-5 main-banner " style="background-image:url('img/main_bg.jpg'); background-repeat: no-repeat; position:relative;">
 
       <div class="overlay" style="position:absolute; top:0;left:0;width: 100%;height: 100%; background: #333;opacity:0.7;"></div> 
<!--slide1 start-->
 <div class="mySlides fade" style="z-index:2;">
 <!-- Header Start -->
 
    <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 mb-3 animated slideInDown" style="color:#F9E39A;">Quality with Timely Supply</h1>
                    <p class="animated slideInDown" style="color:#fff;">Consistent Quality Timely supply are our assurance besides idealy located in Solan - Himachal Pradesh, would serve the business purpose of Third Party Marketers.</p>
                    <a href="#inquiry" class="btn btn-primary py-3 px-4 animated slideInDown" style="background-color:#AC8D4D; border:1px solid #F9E39A;">FRANCHISE ENQUIRY</a>
                </div>
                <div class="col-lg-6 animated fadeIn">
                <img class="img-fluid animated pulse infinite ban-img" style="animation-duration: 3s;border-radius:5px; box-shadow: 2px 2px 10px #AC8D4D;" src="img/hand-mockup.png" alt="" >
                </div>
            </div>
</div>
    <!-- Header End -->
</div>

<!--slide2 start-->

<div class="mySlides fade"  style="z-index:2;">
 <!-- Header Start -->
 
    <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 mb-3 animated slideInDown" style="color:#F9E39A;">Third Party Manufacturing</h1>
                    <p class="animated slideInDown" style="color:#fff;">We have our own manufacturing unit in Solan which operates as per guidelines of GMP / WHO. We help you launch your product with the smallest batch size. Determine your Economic Batch Quantity (EOQ) and we should be able to deliver.</p>
                    <a href="#inquiry" class="btn btn-primary py-3 px-4 animated slideInDown" style="background-color:#AC8D4D; border:1px solid #F9E39A;">FRANCHISE ENQUIRY</a>
                </div>
                <div class="col-lg-6 animated fadeIn">
                <img class="img-fluid animated pulse infinite" style="animation-duration: 3s;border-radius:15px; box-shadow: 2px 2px 10px #AC8D4D;" src="img/hand-mockup.png" alt="" >
                </div>
            </div>
</div>
    <!-- Header End -->
</div>

<!---slide3 start-->

<div class="mySlides fade"  style="z-index:2;">
 <!-- Header Start -->
 
    <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 mb-3 animated slideInDown" style="color:#F9E39A;">Top Pharmaceutical Company</h1>
                    <p class="animated slideInDown" style="color:#fff;">Want to do business with the top PCD Pharma franchise companies in India. If yes then you are at the right place. Orange Group of Companies are amongst the top pharma company and distributor of Pharma PCD and monopoly pharma PCD franchise. At Orange Group of Companies we are focusing on providing you wide range of pharma Products like Tablets, Cough Syrups, Tonics (Product Permission under FDA), Antacids, Laxatives, Paediatric Drops, Expectorants, Mucolytics any many more Formulations.</p>
                    <a href="#inquiry" class="btn btn-primary py-3 px-4 animated slideInDown" style="background-color:#AC8D4D; border:1px solid #F9E39A;">FRANCHISE ENQUIRY</a>
                </div>
                <div class="col-lg-6 animated fadeIn">
                    <img class="img-fluid animated pulse infinite" style="animation-duration: 3s;border-radius:5px; box-shadow: 2px 2px 10px #AC8D4D;" src="img/hand-mockup.png" alt="" >
                </div>
            </div>
</div>
    <!-- Header End -->
</div>









</div>
  
 </div>
 
 

 </div>

       <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<!--slider end-->
   


    <!-- About Start -->
   <section id="about">
    <div class="about-container">
    <div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Orange Group of Companies
                                <span class="sec-title-border">
                                    <span>

                                </span><span></span><span></span></span></h2>
							<p>

							Orange Group of Companies, the most prominent Indian Pharma Companies dedicated to serving the mankind over the long haul. We have set our foot in the year 2003 with a commitment to offer quality healing solutions to million lives for an enhanced living. Working hard from the beginning, we have earned a reputation in the Best Pharma Company in India in the industry for producing an excellent range of healthcare products incorporating Antibiotics, Analgesics, Gynae Care, Nutraceuticals, Injectibles, Suspensions, and various Ayurvedic preparations, distributing across the nation.

                            </p>
						</div>
					</div>
				</div>
    </div>

   </section>
    <!-- About End -->


    <!-- Facts Start -->
    <div class="container-xxl bg-light py-5 my-5" style="margin-top:0px !important; padding-top:0px !important;">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-4 col-md-6 text-center wow fadeIn" data-wow-delay="0.1s">
                <div class="single-about-box">
                     <i class="fas fa-pills" style="font-size:60px; color:#AC8D4D; font-weight:900; margin-bottom: 2rem !important;"></i>
							<h4  style="font-size:25px;">Wide Product Range</h4>
							<p style="color:#333;font-weight:500;">We undertake manufacturing of wide range of pharmaceutical Products like Tablets, Capsules, Cough Syrups, Tonics (Product Permission under FDA), Antacids, Laxatives, Paediatric Drops etc. 
</p>
						</div>
                    
                </div>
                
                <div class="col-lg-4 col-md-6 text-center wow fadeIn" data-wow-delay="0.3s">
                <div class="single-about-box active">
                            <i class="fas fa-signal" style="font-size:60px; color:#AC8D4D; font-weight:900; margin-bottom: 2rem !important;"></i>
							<h4 style="font-size:25px;">Own MAnufacturing unit</h4>
							<p style="color:#333;font-weight:500;">In order to ensure quality products and timely delivery at affordable prices we have our own manufacturing unit in Solan near Baddi (Himachal Pradesh).</p>
                </div>
</div>
                <div class="col-lg-4 col-md-6 text-center wow fadeIn" data-wow-delay="0.5s">
                <div class="single-about-box active">
                            <i class="fas fa-certificate" style="font-size:60px; color:#AC8D4D; font-weight:900; margin-bottom: 2rem !important;"></i>
							<h4 style="font-size:25px;">GMP / WHO approved</h4>
							<p style="color:#333;font-weight:500;">We have GMP / WHO approved manufacturing facilities to ensure world class products.We offer Ultra-modern Packings latest running in the market.</p>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->

    <!--counter start-->
    <section class="counter-area ptb-90">
			<div class="counter-container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
                        <i class="fas fa-heart" style="color:#F9E39A;"></i>
							<h1><span class="counter" style="color:#fff;">900</span></h1>
							<p style="font-weight: bold; padding-bottom:40px;">Brands</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
                        <i class="fas fa-user-shield" style="color:#F9E39A;"></i>
							<h1><span class="counter" style="color:#fff;">1200</span></h1>
							<p style="font-weight: bold;  padding-bottom:40px;">APIs</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
                        <i class="fas fa-download" style="color:#F9E39A;"></i>
							<h1><span class="counter" style="color:#fff;">1000</span></h1>
							<p style="font-weight: bold;  padding-bottom:40px;">Formulations</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
                        <i class="fas fa-trophy" style="color:#F9E39A;"></i>
							<h1><span class="counter" style="color:#fff;">10</span></h1>
							<p style="font-weight: bold;  padding-bottom:40px;">Awards</p>
						</div>
					</div>
				</div>
			</div>
		</section>

     <!--counter end-->

<!---team start-->
<section class="team-area ptb-90" id="products">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Product Range<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Orange Group of Companies offers the wide range of pharmaceutical products through its manufacturing facilities. We manufacturer varieties of solid and liquid oral dosage form with highest standards. Tablets, capsules, powders, injectable  and oral solutions requiring degrees of high-shear granulation, bi-layers, fluid-bed processing, and film coating.Immediate release, extended release, cytotoxic containment, hormone containment, and ODT technology products. Our range includes Tablets, Capsules, Softgels, Syrups, Drops, Ointments, Gels, Oils, Granules, Powders &amp; Shampoos. Our product range is comprehensive and comparable to the widest range by any PCD Pharma company in India. Our products cover segments like Analgesics &amp; NSAIDs, Anti-acids &amp; Gastroenterology, Antibiotics, Anthelmintics, Anti-cough &amp; Cold, Anti-malarial &amp; Anti-Infectives, Anti-Ulcerative, Dental, Dermatology, Gynecology, Genito-Urinary, Hepatology, Multivitamins &amp; Antioxidants, Neurology &amp; Psychiatry, Orthopedics, Paediatrics and Nutraceuticals.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="img/team.jpg" alt="tablets">
								<div class="team-member-icon">
									<div class="display-table">
										 
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h6>Tablets</h6></a>
 							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="img/team2.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										 
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h6>Capsules</h6></a>
 							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="img/team3.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										 
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h6>Syrup</h6></a>
 							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="img/team4.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										 
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h6>Injectables</h6></a>
 							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
<!--team end-->
<!--pcd franchise section start-->
<section class="pcdfranchise-area ptb-90 " style="padding:50px 0;" id="pcdfranchise">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Pharma Franchise Company in India<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p> 


							Orange Group of Companies,   trusted and well-renowned among the various Indian Pharma PCD companies, have been advancing in the direction of developing more valuable and affordable medicinal products. We are an ISO 9001:2008 GMP Certified Ethical Pharmaceutical Company with a great vision of formulating and producing a huge range of products that are focused on enhancing, prolonging and rejuvenating the quality of life among the individuals of the country.Orange Biotech is pleased to be crowned as one of the best PCD Pharma Companies in India offering highest efficiency in terms of the quality of pharmaceutical products.  We invite new entrepreneurs or experienced businesses to join hands with us to promote healthy lives throughout the nation.

  




                                </p>
                            <br>
                            <h3 style="color:#F9E39A;">Monopoly Based Pharma Business Opportunity</h3><br>
                            <p>
                             Joining with this major Pharma PCD Marketing Company as a PCD Pharma franchise you would be helping your own self, refurbishing your skills and sharpening the knowledge to make it more pronounced for the best results. There would be grand opening support and overview of entity choices for a much awaited future.

Keeping in mind the future planning, strategies and ideas, there might be few additional agreements for Pharma franchise. A few considerations for comany's betterment, there always are few requirements to be met as terms and conditions.     
Our job is not done at only manufacturing pharmaceutical products. Being a leading name in pharmaceutical sector we ensure to provide best services from our end to our business partners.
                            
                                 Apart from this we try to keep pace with the changing trends and requirements in the pharmaceutical industry.</p>


								 <!--<marquee height="250px" class="mymarquee">
          

          <img src="img/slider1.jpeg">
          <img src="img/slide2.jpeg">
          <img src="img/slide3.jpeg">
          <img src="img/slide4.jpeg">
          <img src="img/slide5.jpeg">
          <img src="img/slide5.jpeg">
          <img src="img/slide7.jpeg">
          
 
        </marquee>-->



<!--carousal start-->

<div class="main-carousel">
  <div class="cell"><img src="img/slider1.jpeg"></div>
  <div class="cell"><img src="img/slide2.jpeg"></div>
  <div class="cell">  <img src="img/slide3.jpeg"></div>
  <div class="cell">  <img src="img/slide4.jpeg"></div>
  <div class="cell">  <img src="img/slide5.jpeg"></div>
  <div class="cell">  <img src="img/slide6.jpeg"></div>
  <div class="cell">  <img src="img/slide7.jpeg"></div>

</div>
<style>
	.cell{
    width:33%;
    height: 350px;
    margin:0 15px;
    overflow:hidden;
    border-radius: 10px;

}
@media screen and (max-width: 900px) {
	.cell {
		width:100%;
  }
}



.cell img{
    width: 100%;
    height:100%;
    object-fit: cover;
}
</style>


						</div>
					</div>
				</div>
				 
			</div>
		</section>
<!--pcd franchise section end-->
<!--third party start--->
<section class="download-area ptb-90" id="thirdparty">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title" style="color:#fff; ">
							<h2 style="color:#fff;">Third Party Manufacturing<span class="sec-title-border" style="color:#fff;"><span style="color:#fff;"></span>
                            <span style="color:#fff;"></span>
                            <span style="color:#fff;"></span>
                             </span></h2>
							<p style="color:#fff;">The another things which makes company ideal among the parties in Pharma industry for third Party Manufacturing is its state-of-art manufacturing facilities. We are fully integrated with advance machinery and opt modern technology for manufacturing of medicine. Our Manufacturing facilites are certified by WHO, GMP and ISO. Apart from these, our manufacturing place consists of following facilities: 1)  QC lab, R&amp;D analytical testing and R&amp;D manufacturing Facility. 2) We have clinical packaging and warehouse to carry our further activities after manufacturing medicine.
                                3) Licenses 
                                4)  FDA registration
                                </p>
                            <br>
                            <h3 style="color:#fff; ">Our Third Party Pharma Manufacturing Includes Services</h3><br>
                            <p>
                                </p><ul style="color:#fff; "><li>Quality Assurance for the entire product along with clinical trial and lab tastings</li>
                            <li>Help in creating trademark as well as choosing brand name. (If required)</li>
                            <li>Guidance in selecting packaging designs along with packaging material Procurement.</li>
                            <li>Introducing new and innovative molecules</li>
                            <li>1st time supply will execute in 40-45 days. In case of repeat supplies, 
                                they will be execute within 20-25 days.</li>
                              </ul>      
Our job is not done at only manufacturing pharmaceutical products. Being a leading name in pharmaceutical sector we ensure to provide best services from our end to our business partners.
                            
                                 Apart from this we try to keep pace with the changing trends and requirements in the pharmaceutical industry.<p></p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<ul>
							<li>
								 
							</li>
							<li>
								<a href="#inquiry" class="download-btn flexbox-center">
									<div class="download-btn-icon">
										<i class="icofont icofont-search"></i>
									</div>
									<div class="download-btn-text" >
										<a href="#inquiry"><p style="color:#fff; background: green; padding:10px 10px;border-radius:20px;box-shadow: 2px 2px 10px #333; text-align:center;">Franchise Enquiry</p>
										</a>
									</div>
								</a>
							</li>
							<li>
								 
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>
<!--third party end--->

<!--footer start-->
<footer class="footer" id="inquiry">
			<div class="container">
				<div class="row">
                    <div class="col-lg-6">
						<div class="contact-form">
							<h4>Franchise Form</h4>
 							 
                            
                            
                            <form id="contact2" class="qform cf" action="mail.php" method="post" onsubmit="">
                                               <div class="full left cf" style="">
                                                
											   <b>I am looking for  </b>
                                                
                                                <input type="radio" name="TYPE" value="PCD FRANCHISE" checked=""> Pharma Franchise
                                                   
												 <br>
                                                I have ( Tick ) <input type="checkbox" name="drugLicense" value="Yes"> Drug Licence
                                                <input type="checkbox" name="gstNo" value="Yes"> GST Number<br>

                                                
                                                
                                               
<br>
												 <b>My Franchise Area for PCD will be </b><br>
                                                
                                                <input type="text" id="input-message" placeholder="Area for franchise ( State / District )" title="Enter your working area" name="FranchiseArea" required="">

												<b>My details for Franchise</b><br>

												<input type="text" id="input-name" placeholder="Name" name="Name" title="Enter Your name" required="">
                                                 
                                                 <input type="email" id="input-email" placeholder="Email address" name="EmailID">
                                                 
                                                 <input type="tel" id="input-subject" placeholder="Mobile" title="Enter your Mobile Number" name="ContactNumber" required="">
                                                 <input type="text" id="input-subject" placeholder="Address" title="Enter your Address" name="Address" required="">
                                                 
                                                                                        
                
                                               <!--- <input type="hidden" value="96" name="ID">
                                                <input type="hidden" value="ORANGEBIOTECH" name="COMPCODE">
                                                <input type="hidden" value="Google Adwords" name="reference">
                                                
                                                 <input type="hidden" value="PCEtLSBHbG9iYWwgc2l0ZSB0YWcgKGd0YWcuanMpIC0gR29vZ2xlIEFkczogMzE0MjY0Nzc0IC0tPg0KPHNjcmlwdCBhc3luYyBzcmM9Imh0dHBzOi8vd3d3Lmdvb2dsZXRhZ21hbmFnZXIuY29tL2d0YWcvanM/aWQ9QVctMzE0MjY0Nzc0Ij48L3NjcmlwdD4NCjxzY3JpcHQ+DQogIHdpbmRvdy5kYXRhTGF5ZXIgPSB3aW5kb3cuZGF0YUxheWVyIHx8IFtdOw0KICBmdW5jdGlvbiBndGFnKCl7ZGF0YUxheWVyLnB1c2goYXJndW1lbnRzKTt9DQogIGd0YWcoJ2pzJywgbmV3IERhdGUoKSk7DQoNCiAgZ3RhZygnY29uZmlnJywgJ0FXLTMxNDI2NDc3NCcpOw0KPC9zY3JpcHQ+" name="AD_CODE1">
                                                  <input type="hidden" value="PCEtLSBFdmVudCBzbmlwcGV0IGZvciBXZWJzaXRlIGxlYWQgY29udmVyc2lvbiBwYWdlIC0tPg0KPHNjcmlwdD4NCiAgZ3RhZygnZXZlbnQnLCAnY29udmVyc2lvbicsIHsnc2VuZF90byc6ICdBVy0zMTQyNjQ3NzQvWmZFVENJemwydkFDRU1hWjdaVUInfSk7DQo8L3NjcmlwdD4=" name="AD_CODE2">
                                                  
                                                  
                                                
                                                <input type="hidden" value="Google Adwords" name="reference">-->
                                            	




                                              </div>
											  <p style="color:red; font-weight:500;">Note: Before you apply you make sure you have a DL licence.</p><br>

                                              <input type="submit" value="Submit" id="input-submit" name="submit">
                                            </form>
                            
                            
                            
						</div>
                    </div>
                    <div class="col-lg-6">
						<div class="contact-address" style="background:none; border:0px; color:#fff">
							<h4 style="color:#fff">Address</h4>
							<p>Orange Group of Companies, <br>#25 Dukheri Road,   Vill. Mohra, Ambala Cantt.-133004 HARYANA.</p>
							<ul>
								<li>
									<div class="contact-address-icon">
                                    <i class="fas fa-headphones"></i>
									</div>
									<div class="contact-address-info">
										<a href="tel:9499164372, 9034065531">9499164372, 9034065531</a>
 									</div>
								</li>
								<li>
									<div class="contact-address-icon">
                                    <i class="fas fa-envelope"></i>
									</div>
									<div class="contact-address-info">
										<a href="mailto:support@orangebiotech.in">support@orangebiotech.in</a>
									</div>
								</li>
								<li>
									<div class="contact-address-icon">
                                    <i class="fas fa-globe"></i>
									</div>
									<div class="contact-address-info">
										<a href="http://www.orangebiotech.in">www.orangebiotech.in</a>
									</div>
								</li>
							</ul>
						</div>
                    </div>
				</div>
			 
				<div class="row">
                    <div class="col-lg-12">
						<div class="copyright-area">
							 
							<p>© <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright ©<script>document.write(new Date().getFullYear());</script> All rights reserved  <span style="text-decoration:none;opacity:0.25;border:0px"> | Theme <a href="" style="border:0px" target="_blank">ethix</a>  |</span> <a href="">Online Promotions by <i class="fa fa-heart-o" aria-hidden="true"></i>  ethix</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
						</div>
                    </div>
				</div>
			</div>
			

				
		</footer>


<!---footer end-->


<!---sticky bottom navibar--->
<div class="bottom-container">
<nav class="bottom-nav">
  <a href="" class="bottom-link"><span class="material-symbols-outlined">
phone_in_talk
</span>
<i>Call us</i>
</a>
<a href="" class="bottom-link"><img src="img/whatsup.png" alt="" style="width:20px; height: 20px;">
<i>Whats up</i>
</a>

<a href="" class="bottom-link"><img src="img/gmail.png" alt="" style="width:20px; height: 20px;">
<i>Contact us</i>
</a>

</nav>
    

</div>

<style>
    .bottom-nav{
        position:fixed;
        bottom:0;
        width: 100%;
        height:55px;
        box-shadow: 0 0 3px rgba(0,0,0,0.2);
        background-color: #ffff;
        overflow-x:auto;
        display: flex;
        z-index: 2;
       
    }
    .bottom-link{
        display: flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        flex-grow:1;
        min-width: 50px;
        overflow: hidden;
        white-space:nowrap;
        font-size:14px;
        color:#333;
        text-decoration: none;
        -webkit-tap-highlight-color: transparent;
        transition: background-color 0.1s  ease-in-out;
    }
    .bottom-link:hover{
        text-decoration: none;
    }
    .bottom-container{
        display:none;
    }
@media screen and (max-width:768px) {
    .bottom-container{
        display: block;
    }
}
</style>

    


    
               


    

    
                   


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>
   <a id="myformlink" onclick="hide()">Enquiry Form </a>
   <script>

function hide(){
	document.getElementById('myformlink').style.display='none';
	location.href="#inquiry";

}

 

</script>
<script type="text/javascript">    
           $('.js-scroll-trigger').click(function() {
    $('.navbar-collapse').collapse('hide');
  });
      </script>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script src="js/script.js"></script>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<!-- JavaScript -->
<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script>
	$('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll:true
 
});
</script>
</body>

</html>